#include "basic.h"

#include <string>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <numeric>
#include <chrono>
#include <list>
#include <algorithm>
#include <functional>
#include <array>
#include <string_view>

void duomenys::setStudentas(std::string Vard_, std::string Pav_, std::string egz_){
    Vard_ = Vard_;
    Pav_ = Pav_;
    egz_ = std::stoi(egz_);
}

void duomenys::SetPaz(int Score){
    paz_.push_back(Score);
}

void duomenys::EmptyPaz(){
    paz_.clear();
}


double duomenys::GP(int egz, double paz){
    return 0.4 * paz + 0.6 * egz;
}


double duomenys::GalPaz(double (*kas)(std::vector<int>)){
    return GP(egz_, kas(paz_));
}


double Vidurkis(std::vector<int> paz){
    return std::accumulate(paz.begin(), paz.end(), 0.0) / paz.size();
}

double Mediana(std::vector<int> paz){
    typedef std::vector <int>::size_type VecSize;
    VecSize size = paz.size();

    sort(paz.begin(), paz.end());

    VecSize Middle = size / 2;
    if (size % 2 == 0)
        return (paz[Middle - 1] + paz[Middle]) / 2;
    else
        return paz[Middle];
}
bool Lyginimas(const duomenys& x, const duomenys& y)
{
    return x.getPavarde() < y.getPavarde();
}

int Pasirinkimas()
{
	int kuris;
	std::cout << "Kuri faila norite isrusiuoti?\n 1 - studentai1000.txt\n 2 - studentai10000.txt\n 3 - studentai100000.txt\n 4 - studentai1000000.txt\n 5 - studentai10000000.txt" << std::endl;
	std::cin >> kuris;
	int kiek;
	int kiek_paz;
	if (kuris == 1) { kiek = 1000; kiek_paz = 15; };
	if (kuris == 2) { kiek = 10000, kiek_paz = 15; };
	if (kuris == 3) { kiek = 100000; kiek_paz = 20; };
	if (kuris == 4) { kiek = 1000000; kiek_paz = 7; };
	if (kuris == 5) { kiek = 10000000; kiek_paz = 7; };

	int kaip=1;
	//std::cout << "Skaiciuoti pagal vidurki-1 ar mediana-0?" << std::endl;
	//std::cin >> kaip;

    return kiek, kiek_paz, kaip;
}
