#pragma once
#ifndef BASIC_H_INCLUDED
#define BASIC_H_INCLUDED
#include <string>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <numeric>
#include <chrono>
#include <list>
#include <algorithm>
#include <functional>
#include <array>
#include <string_view>

/*struct duomenys {
std::string Vard, Pav;
	std::vector<int> paz = { 0 };
	int egz;
	float GP = 0;
};*/

class duomenys
{
private:
    std::string Vard_;
    std::string Pav_;
    std::vector<int> paz_;
    int egz_;
public:
    duomenys() : paz_(0) { };
    void setStudentas(std::string, std::string, std::string);
    void SetPaz(int);
    void EmptyPaz();
    std::string getVardas() const { return Vard_; }
    std::string getPavarde() const { return Pav_; }
    int GetEgz() const { return egz_; }
    int GetDydis() const { return paz_.size(); }
    double GP(int, double);
    double GalPaz(double (*) (std::vector<int>));
};
int Pasirinkimas();
bool Lyginimas(const duomenys&, const duomenys&);
double Vidurkis(std::vector<int>);
double Mediana(std::vector<int>);

#endif
