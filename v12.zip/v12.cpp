#include "basic.h"

int main() {
	int kuris = Pasirinkimas();
	int kiek = Kiek_mokiniu(kuris);
	int kiek_paz = Kiek_pazymiu(kuris);
	int kaip = Kaip();

	std::string Vard_, Pav_, egz_;
	std::vector<duomenys> Eil;
	duomenys Stud;



	std::string pavadinimas = "Studentai_" + std::to_string(kiek) + ".txt";
	std::string buff;
	std::ifstream fileRead(pavadinimas);

	if (fileRead.is_open()) {

		getline(fileRead >> std::ws, buff);

		//auto start = std::chrono::high_resolution_clock::now();
		int studento_nr = 0;
		while (studento_nr < kiek) {

			fileRead >> Vard_ >> Pav_ >> egz_;
			Stud.setStudentas(Vard_, Pav_, egz_);

			Stud.EmptyPaz();
			for (int j = 0; j <= kiek_paz; j++) {
				int a;
				fileRead >> a;
				Stud.SetPaz(a);
			}
			fileRead >> egz_;
			Eil.push_back(Stud);
			fileRead.clear();
			studento_nr++;
		}


		//auto end = std::chrono::high_resolution_clock::now();
		//std::chrono::duration<double> diff = end - start;
		//std::cout << "Failo nuskaitymas su vector uztruko: " << diff.count() << " s\n";
	}

	auto start = std::chrono::high_resolution_clock::now();

	std::vector<duomenys> vargsiukai, protingi;
	std::vector<duomenys>::iterator IT = Eil.begin();

	while (IT != Eil.end())
	{
		if (kaip == 1)
		{
			if ((*IT).GP(Vidurkis) < 5)
				vargsiukai.push_back(*IT);
			else
				protingi.push_back(*IT);
			IT++;

		}
		if (kaip == 2)
		{
			if ((*IT).GP(Mediana) < 5)
				vargsiukai.push_back(*IT);
			else
				protingi.push_back(*IT);
			IT++;

		}
	}
	auto end = std::chrono::high_resolution_clock::now();
	std::chrono::duration<double> diff = end - start;
	std::cout << "VECTOR: rusiavimas 1 strategija  : " << std::fixed << diff.count() << " s\n";
}